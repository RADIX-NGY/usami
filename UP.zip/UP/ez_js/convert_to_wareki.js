function toWareki(year, month, day, nendo)
{
    var wareki = "";
    year = Number(year);
    if(nendo){
        //1~3月なら昨年4月の年度を設定
        if(month >= 1 && month <= 3){
            year--;
            month = 4;
            day = 1;
        }
        else{
            month = 4;
            day = 1;
        }
    }
    if (year == 1868) {
        /* 9月8日から明治元年 */
        /* 誕生日がここの人はいないだろうから細かくは気にしない */
        wareki = '明治元年';
    } else if (1868 < year && year < 1912) {
        year = year - 1867;
        wareki = '明治' + year + '年';
    } else if (year == 1912) {
        year = year - 1867; // 明治46年7月30日まで明治 // 明治46年7月31日から大正
        if (month < 7 || (month == 7 && day < 31)) {
            wareki = '明治' + year + '年';
        } else {
            wareki = '大正元年';
        }
    } else if (1912 < year && year < 1926) {
        year = year - 1911;
        wareki = '大正' + year + '年';
    } else if (year == 1926) {
        year = year - 1911;
        if (month < 12 || (month == 12 && day < 25)) {
            wareki = '大正' + year + '年';
        } else {
            wareki = '昭和元年';
        }
    } else if (1926 < year && year < 1989) {
        year = year - 1925;
        wareki = '昭和' + year + '年';
    } else if (year == 1989) {
        year = year - 1925;
        if (month == 1 && day < 7) {
            wareki = '昭和' + year + '年';
        } else {
            wareki = '平成元年';
        }
    } else if (1988 < year) {
        year = year - 1988;
        wareki = '平成' + year + '年';
    } else {
        wareki = '--年';
    }
//    return  wareki + month + "月" + day + "日";
    return nendo ? wareki + "度" : wareki;
} 