$(function () {
  $(".fuwatto").each(function () {
    var fuwatto = this;
    var content = $(fuwatto).find(".fuwatto_content").get(0);

    $(fuwatto).find(".fuwatto_navi a").each(function () {
      var url = $(this).prop("href");
      $(this).prop("href", "javascript:void(0);");
      $(this).attr("fuwatto-href", url);
    });

    var offset = fuwatto.getAttribute("fuwatto-offset");
    if (offset === undefined || !offset || offset === "" || offset.match(/[^-\d]/)) {
      offset = 0;
    } else {
      offset = parseInt(offset);
    }

    var speed = fuwatto.getAttribute("fuwatto-speed");
    if (speed === undefined || !speed || speed === "") {
      speed = "noraml";
    }
    if (!speed.match(/\D/)) {
      speed = parseInt(speed);
    }

    var selectClass = fuwatto.getAttribute("fuwatto-select-class");
    if (selectClass === undefined || !selectClass || selectClass === "") {
      selectClass = "selected";
    }

    var selectElement = fuwatto.getAttribute("fuwatto-select-element");
    if (selectElement === undefined || !selectElement || selectElement === "") {
      selectElement = "";
    }

    $(fuwatto).find(".fuwatto_navi a").click(function () {
      var a = this;
      $(fuwatto).find(".fuwatto_navi *").removeClass(selectClass);
      if (selectElement !== "") {
        $(a).parents(selectElement).addClass(selectClass);
      } else {
        $(a).addClass(selectClass);
      }
      $(content).slideUp(
        speed,
        function () {
          $.ajax($(a).attr("fuwatto-href"), {
            timeout: 60000, // 60000 ms
            datatype: 'html'
          }).then(function (data) {
            $(content).empty();

            var parsed = $($.parseHTML(data));
            var page_fuwatto = $(parsed).filter("#" + $(fuwatto).prop("id"));

            if (page_fuwatto.length > 0) {
              var page_fuwatto_coontent = $(page_fuwatto.get(0).innerHTML).filter(".fuwatto_content");

              if (page_fuwatto_coontent.length > 0) {
                if (page_fuwatto_coontent.get(0).innerHTML.match(/\S/)) {
                  $(content).append(page_fuwatto_coontent.get(0).innerHTML);
                  $(content).slideDown(speed,function(){
                    $('html,body').animate({scrollTop: $(fuwatto).offset().top - offset}, speed, 'swing');
                  });
                }
              }
            }
          }, function (jqXHR, textStatus) {

          });
        });
      return false;
    });
  });
});