////////////////////////
// ez_gmap.js 1.0.2   //
// 2017-11-09         //
// ezgate             //
////////////////////////


/**
 * １．このスクリプトについて
 * class="gmap"を付けたdivをGoogleMapへ変化させます。
 * 該当するdivの属性に様々なオプションを記述することが出来ます。
 * 
 * また、該当クラスの内部にclass="marker"もしくはclass="maker"を指定したdivを設置すると、
 * 設置したdivの内容に応じたマーカーを地図上に表示します。
 * 本体と同じく、いくつかのオプションがあります。
 * div要素の内容そのものはマーカーをクリックした際に子ウィンドウとして表示されます。
 * 
 * 
 * 
 * ２．APIキーについて
 * このスクリプトを読み込む前に「gmap_key」変数に前もってAPIキーを指定しておくと、
 * GoogleMapAPIのJS読み込み時にAPIキーを付加します。
 * 
 * 
 * 
 * ３．本体オプション一覧
 * data-width: 地図の横幅を％で指定します。単位は記述しないでください。指定しない場合、CSS等でのサイズに準拠します。
 * data-height: 地図の高さをピクセルで指定します。単位は記述しないでください。指定しない場合、CSS等でのサイズに準拠します。
 * data-mobile-width: モバイル機器からのアクセス時の地図の横幅を％で指定します。記述方法や指定がない場合の動作はdata-widthに準拠します。
 * data-mobile-height: モバイル機器からのアクセス時の地図の高さをピクセルで指定します。記述方法や指定がない場合の動作はdata-heightに準拠します。
 * 
 * data-lat: 地図の基準地点の緯度を指定します。data-boundがOFFの時中心地点の緯度となります。
 * data-lng: 地図の基準地点の経度を指定します。data-boundがOFFの時中心地点の経度となります。
 * data-bound: 地点に応じた自動拡縮を指定します。1がONで0がOFFです。指定しない場合はONとなります。
 * data-zoom: 地図の初期状態の縮尺を指定します。数字が大きいほど拡大され、狭い範囲の表示となります。data-boundが0の時有効となります。
 * 
 * data-type: 地図の種別を指定します。指定できる値についてはGoogleMapAPIのマニュアルを参照してください。初期値は"ROADMAP"です。
 * 
 * data-title: 地図の基準地点のタイトルを指定します。
 * data-icon: 地図の基準地点のアイコンのURLを指定します。
 * data-window: 地図の基準地点がウィンドウを持つかどうかのURLを指定します。
 * 
 * 
 * 
 * ４．マーカーオプション一覧
 * data-lat: マーカーの緯度を指定します。
 * data-lng: マーカーの経度を指定します。
 * 
 * data-title: マーカーのタイトルを指定します。
 * data-icon: マーカーのアイコンを指定します。
 * data-window: マーカーが子ウィンドウを持つかどうかを指定します。指定しなかった場合、子ウィンドウは表示されません。
 * 
 * 
 * 
 * ５．設定例

<div class="gmap" id="locationmap">
	<div class="gmarker" data-lat="35.692757" data-lng="139.7785308" data-title="株式会社イージーゲート"><p><a href="http://www.ezgate.co.jp/">WEB制作会社</a></p></div>
</div>

 */


if (typeof gmap_key === "undefined") {
  gmap_key = '';
} else {
  gmap_key = '&key='+gmap_key;
}
document.write('<sc' + 'ript src="http://maps.google.com/maps/api/js?sensor=false' + gmap_key + '"></sc' + 'ript>');
function addEventSet(elm, listener, fn) {
  try {
    elm.addEventListener(listener, fn, false);
  } catch (e) {
    elm.attachEvent("on" + listener, fn);
  }
}
var gmaps = new Array();
function gmaps_init() {
  var tagObj = document.getElementsByTagName("div");
  for (var i = 0; i < tagObj.length; i++) {
    if (tagObj[i].className === "gmap") {
      gmaps[tagObj[i].id] = new gmap(tagObj[i]);
    }
  }
}
function gmap_move(map, marker, zoom) {
  gmaps[map].move(marker, zoom);
}
function gmap(obj) {
  this.init = function (obj) {
    this.Default = {
      "width": null,
      "height": null,
      "mobile-width": null,
      "mobile-height": null,
      "lat": null,
      "lng": null,
      "zoom": "13",
      "bound": "1",
      "title": "Map",
      "type": "ROADMAP",
      "icon": null,
      "window": false,
      'multiwindow': false
    };

    this.Width = this.att(obj, "data-width") === null ? null : Number(this.att(obj, "data-width"));
    this.Height = this.att(obj, "data-height") === null ? null : Number(this.att(obj, "data-height"));
    this.MobileWidth = this.att(obj, "data-mobile-width");
    this.MobileHeight = this.att(obj, "data-mobile-height");
    this.Lat = this.att(obj, "data-lat") === null ? null : Number(this.att(obj, "data-lat"));
    this.Lng = this.att(obj, "data-lng") === null ? null : Number(this.att(obj, "data-lng"));
    this.Zoom = Number(this.att(obj, "data-zoom"));
    this.Bound = Number(this.att(obj, "data-bound")) > 0 ? true : false;

    this.Type = this.att(obj, "data-type");
    this.Title = this.att(obj, "data-title");
    this.Icon = this.att(obj, "data-icon");
    this.Window = this.att(obj, "data-window");
    this.MultiWindow = this.att(obj, "data-multiwindow");

    this.mobile();
    this.container = obj;
    this.HTML = this.container.innerHTML;
    this.Markers = new Array();
    this.MarkerLat = 0;
    this.MarkerLng = 0;
    this.Infowindow = new Array();
    this.MarkerIndex = new Array();
    this.CurrentInfowindow = null;
    var childs = this.container.childNodes;
    for (var i = 0; i < childs.length; i++) {
      if (childs[i].className === "gmaker" || childs[i].className === "gmarker") {
        this.Markers[this.Markers.length] = new Object();
        this.Markers[this.Markers.length - 1].Title = this.att(childs[i], "data-title");
        this.Markers[this.Markers.length - 1].Lat = Number(this.att(childs[i], "data-lat"));
        this.Markers[this.Markers.length - 1].Lng = Number(this.att(childs[i], "data-lng"));
        this.Markers[this.Markers.length - 1].HTML = childs[i].innerHTML;
        this.Markers[this.Markers.length - 1].Icon = this.att(childs[i], "data-icon");
        this.Markers[this.Markers.length - 1].Window = this.att(childs[i], "data-window");
        this.Markers[this.Markers.length - 1].Id = childs[i].id;
        this.MarkerLat += this.Markers[this.Markers.length - 1].Lat;
        this.MarkerLng += this.Markers[this.Markers.length - 1].Lng;
      }
    }

    if (this.Width !== null) {
      this.container.style.width = this.Width + "%";
    }
    if (this.Height !== null) {
      this.container.style.height = this.Height + "px";
    }

    var myLatlng = null;
    if (this.Markers.length > 0) {
      if (this.Lat === null && this.Lng === null) {
        myLatlng = new google.maps.LatLng(this.Markers[0].Lat, this.Markers[0].Lng);
      }
    } else {
      this.Markers[0] = new Object();
      this.Markers[0].Title = this.Title;
      this.Markers[0].Lat = this.Lat;
      this.Markers[0].Lng = this.Lng;
      this.Markers[0].HTML = this.container.innerHTML;
      this.Markers[0].Icon = this.Icon;
      this.Markers[0].Window = this.Window;
    }

    if (myLatlng === null) {
      myLatlng = new google.maps.LatLng(this.Lat, this.Lng);
    }

    var myOptions = {
      zoom: this.Zoom,
      center: myLatlng,
      mapTypeId: google.maps.MapTypeId[this.Type]
    }
    this.map = new google.maps.Map(obj, myOptions);

    var bounds = new google.maps.LatLngBounds();
    bounds.extend(myLatlng);
    var bound = 1;
    for (var i = 0; i < this.Markers.length; i++) {
      var latlng = new google.maps.LatLng(this.Markers[i].Lat, this.Markers[i].Lng);
      if (this.Markers[i].Id)
        this.MarkerIndex[this.Markers[i].Id] = i;
      this.Markers[i].marker = new google.maps.Marker({
        position: latlng,
        map: this.map,
        title: this.Markers[i].Title,
        num: i,
        icon: this.Markers[i].Icon
      });
      this.Infowindow[i] = new google.maps.InfoWindow({
        content: this.Markers[i].HTML
      });
      google.maps.event.addListener(this.Markers[i].marker, 'click', function () {
        if (gmaps[obj.id].CurrentInfowindow !== null && !this.MultiWindow) {
          gmaps[obj.id].Infowindow[gmaps[obj.id].CurrentInfowindow].close();
        }
        gmaps[obj.id].CurrentInfowindow = this["num"];
        gmaps[obj.id].Infowindow[this["num"]].open(gmaps[obj.id].map, gmaps[obj.id].Markers[this["num"]].marker);
      });
      if (this.Markers[i].Window) {
        this.Infowindow[i].open(this.map, this.Markers[i].marker);
      }
      bounds.extend(latlng);
      bound++;
    }

    if (this.Bound === true) {
      // 表示範囲を広げるため、地図に含まれる地点を追加
      var extendPoint1 = new google.maps.LatLng(bounds.getNorthEast().lat() + 0.01, bounds.getNorthEast().lng() + 0.01);
      var extendPoint2 = new google.maps.LatLng(bounds.getSouthWest().lat() - 0.01, bounds.getSouthWest().lng() - 0.01);
      bounds.extend(extendPoint1);
      bounds.extend(extendPoint2);

      // 地図の表示範囲を決定
      this.map.fitBounds(bounds);
    }
  };
  this.move = function (marker, zoom) {
    if (this.CurrentInfowindow !== null && !this.MultiWindow) {
      this.Infowindow[this.CurrentInfowindow].close();
    }
    var myLatlng = new google.maps.LatLng(this.Markers[this.MarkerIndex[marker]].Lat, this.Markers[this.MarkerIndex[marker]].Lng);
    this.Infowindow[this.MarkerIndex[marker]].open(this.map, this.Markers[this.MarkerIndex[marker]].marker);
    this.map.setCenter(myLatlng);
    this.CurrentInfowindow = this.MarkerIndex[marker];
    if (zoom > 0 && zoom < 20)
      this.map.setZoom(zoom);
  };
  this.att = function (obj, att) {
    if (obj.getAttribute(att) != undefined) {
      return obj.getAttribute(att);
    } else {
      return this.Default[att.replace("data-", "")];
    }
  };
  this.mobile = function () {
    var n = navigator.userAgent;
    if (n.indexOf('Mobile') > -1 && n.indexOf('iPad') === -1) {
      if (this.MobileWidth !== null) {
        this.Width = this.MobileWidth;
      }
      if (this.MobileHeight !== null) {
        this.Height = this.MobileHeight;
      }
    }
  };
  this.init(obj);
}
addEventSet(window, "load", function () {
  gmaps_init();
});